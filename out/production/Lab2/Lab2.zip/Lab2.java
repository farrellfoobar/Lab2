class Lab2
{

    public static void main(String[] args)
    {
        CrapsSimulation c1 = new CrapsSimulation();
        c1.start();
    }

}