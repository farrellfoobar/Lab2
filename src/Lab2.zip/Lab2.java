/*
Patrick Farrell
51043027

This class simply creates a CrapsSimulation object to test / play the game.

 */

class Lab2
{

    // creates a game
    public static void main(String[] args)
    {
        CrapsSimulation c1 = new CrapsSimulation();
        c1.start();
    }

}